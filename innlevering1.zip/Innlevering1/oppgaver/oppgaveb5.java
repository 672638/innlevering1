import java.util.Scanner;
public class oppgaveb5 {

public static void main ( String []args ) {
		
		
		System.out.println("Dette programmet skal gi karakter basert på poengsum") ;
		System.out.println("Skriv inn poengsum: ");
		
		
		Scanner scan = new Scanner(System.in);
		String s = scan.next();
		int i = scan.nextInt();
		
		 
		 
		 int [] grades = {34, 46, 55, 56, 68, 70, 85, 86, 88, 95, 101};
	         int a=grades[i];
			 if (a>=0 && a<=39) {
				 kar("F");
			 }else if (a>40 && a<49) {
				 kar("E");
			 }else if (a>50 && a<59) {
				 kar("D");
			 }else if (a>60 && a<79) {
				 kar("C");
			 }else if (a>80 && a<89) {
				 kar("B");
			 }else if (a>90 && a<100) {
				 kar("A");
			 }else {
				 System.out.println("error");
			 }
		 }
		 
	 
    public static void kar(String string) {
    	System.out.println("Din karakter er: "+string+" \n");
    }
    }
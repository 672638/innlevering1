import java.util.Scanner;

public class oppgaveb4 {
	
	public static void main(String[]args) {
		

		System.out.println("Dette programmet skal gi beregne og skrive ut trinnskatt") ;
		System.out.println("Skriv inn bruttoinntekt: ");
		
		
		
		Scanner scan = new Scanner(System.in);
		String s = scan.next();
		int i = scan.nextInt();
		
		
		
		
		int x=600000;
		if (x>0 && x<164101); {
			System.out.println(x);
		} if (x>=164101 && x<=230950) {
			multiply(x, 0.93);
		}else if (x>=230951 && x<=580650) {
			multiply(x, 2.41);
		}else if (x>=580651 && x<=934050) {
			multiply(x, 14.52);
		}else {
			System.out.println("ikke ett tall");
		}
}

	private static void multiply(int a, double b) {
		// TODO Auto-generated method stub
	System.out.println(a/100*b);
		
	}
	
}
